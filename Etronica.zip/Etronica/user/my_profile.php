<?php
session_start();
?>


<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>My Profile</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/login.css">	
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">


    
</head>
<body>


        <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <?php require('header.php'); ?>
  
<div class="content mt-3">            
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
//$search = $_POST['search'];
  
$search = $_SESSION['login_user'];
   $sql = "SELECT * FROM student_info WHERE prn='$search'";
   $result = $conn->query($sql);
   if ($result->num_rows > 0) {

  echo '<div class="container">
	<div class="row">   	 
	    <div class="col-md-8 col-xs-12 col-sm-12">
	<div class="alert alert-success">';
    // output data of each row
    while($row = $result->fetch_assoc()) {
	echo '<h3><span class="menu-icon ti-user"</sapn>   Personal Information<hr></h3>';
        echo '  <h5> Name: '.$row["fname"].' '.$row["mname"].' '.$row["lname"].'</h5>
		<h5> Roll No.: '.$row["prn"].'</h5>
		<span>Mobile : '.$row["umob"].'</span><br>
		<span>Email : '.$row["email"].'</span><br>
		<span>Aadhar No : '.$row["aadhar"].'</span><br>
		<span>Address : '.$row["address"].'</span><br>
		<span>Parent Name : '.$row["parent"].'</span><br>
		<span>Blood Group : '.$row["blood"].'</span><br>
		<span>Date of Birth : '.$row["dob"].'</span><br>';			

	echo '<br><br><h3><span class="menu-icon ti-car"</sapn>   Educational Profile<hr></h3>';
	echo '  <span> SSC Passing Year : '.$row["sscyear"].'</span><br>
		<span> SSC School :'.$row["sscschool"].'</span><br>
		<span> SSC Percentage : '.$row["sscpercentage"].'</span><br>
		<span> HSC Passing Year : '.$row["hscyear"].'</span><br>
		<span> HSC School :'.$row["hscschool"].'</span><br>
		<span> HSC Percentage : '.$row["hscpercentage"].'</span>';
	}	

	echo '</div></div></div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No User found to display
</div>';
}
$conn->close();
?>
  
        
        </div> <!-- .content -->
    </div><!-- /#right-panel -->


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script>
    
    </script>

</body>
</html>
