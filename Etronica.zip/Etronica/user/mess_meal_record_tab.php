<?php
//session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN= $_GET["prn"];
$PRN = $_SESSION['login_user'];
$i = 1;
   $sql = "SELECT * FROM mess_meal_record WHERE PRN='$PRN'";
   $result = $conn->query($sql);

   $sql1 = "SELECT * FROM mess_payment_record WHERE PRN='$PRN'";
   $result1 = $conn->query($sql1);
   if ($result->num_rows > 0) {

 echo '<div class="container">
	<div class="row">
	    <div class="col-md-8 col-xs-12 col-sm-12">
		<h4 style="text-transform:uppercase">'.$PRN.' has Taken Meal as Follows<br> <br></h4>
		<table class="table table-bordered table-striped">
		<thead class="text-primary"><tr>
		<td>Sr.</td>
		<td>Lunch</td>
		<td>Dinner</td>
	
		</thead>';
    // output data of each row
    while($row = $result->fetch_assoc()) {

        echo '  
		<tr>
		<td>'.$i++.'</td>
		<td>'.$row["lunch"].'</td>
		<td>'.$row["Dinner"].'</td>
		</tr>';
	}	

	echo '</table></div>';
//Payment Summery Block Starts Here

	echo ' <div class="col-md-4 col-xs-12 col-sm-12" style="background-color:orange;padding-top:20px;">
<h4 style="text-transform:uppercase">Payment Summery<br> <br></h4>
	<table class="table table-bordered table-striped">
		<thead class="text-primary"><tr>
		<td>Date</td>
		<td>Amount Paid</td>
		</thead>';
 while($row = $result1->fetch_assoc()) {

        echo '  
		<tr>
		<td>'.$row["PayDate"].'</td>
		<td>'.$row["Amount"].'</td>
		</tr>';
	}	

	echo '</table></div>
</div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Data found to display
</div>';
}
$conn->close();
?>

