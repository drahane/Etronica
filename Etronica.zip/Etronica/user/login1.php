<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) 
{
	if (empty($_POST['username']) || empty($_POST['password'])) 
	{
		$error = "Username or Password is invalid";
		header("location: login.php"); 
	}
	else
	{
		// Define $username and $password
		$username=$_POST['username'];
		$password=$_POST['password'];
		// Establishing Connection with Server by passing server_name, user_id and password as a parameter
		$servername = "localhost";
		$uname = "root";
		$pass = "";
		$dbname = "etronica";
		// Create connection
		$connection = new mysqli($servername, $uname, $pass, $dbname);
		// Check connection
		if ($connection->connect_error) 
		 {
		    die("Connection failed: " . $connection->connect_error);
	       	 }
		
		// To protect MySQL injection for Security purpose
		$username = stripslashes($username);
		$password = stripslashes($password);
		$username = mysql_real_escape_string($username);
		$password = mysql_real_escape_string($password);

		// SQL query to fetch information of registerd users and finds user match.
		
	$sql = "SELECT * FROM student_info WHERE prn='$username' AND userpass ='$password'";
		 $result = $connection->query($sql);
		 if ($result->num_rows == 1) 
		  {
			while($row = $result->fetch_assoc()) 
			{		
				$_SESSION['login_user'] = $row["prn"];
				header("location: index.php"); // Redirecting To Other Page

			} 
		  }
		else
		 {
			$error = "Username or Password is invalid";
			header("location: login.php");

	   	 }
		$connection -> close(); // Closing Connection
	}
}
?>
