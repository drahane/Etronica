<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN= $_GET["prn"];
$PRN = $_SESSION['login_user'];
$i = 1;
   $sql = "SELECT * FROM hostel_entry_record WHERE PRN='$PRN'";
   $result = $conn->query($sql);
   if ($result->num_rows > 0) {

 echo '<div class="container">
	<div class="row">
	    <div class="col-md-11 col-xs-12 col-sm-12">
		<h4 style="text-transform:uppercase">'.$PRN.' has Entered in Hostel as Follows<br> <br></h4>
		<table class="table table-bordered table-striped">
		<thead class="text-primary"><tr>
		<td>Sr.</td>
		<td>Date</td>
		<td>ENTRY TIME</td>
		<td>Direction</td>
	
		</thead>';
    // output data of each row
    while($row = $result->fetch_assoc()) {

        echo '  
		<tr>
		<td>'.$i++.'</td>
		<td>'.$row["ScanDate"].'</td>
		<td>'.$row["ScanTime"].'</td>
		<td>IN</td>
		</tr>';
	}	

	echo '</table></div>

</div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Data found to display
</div>';
}
$conn->close();
?>

