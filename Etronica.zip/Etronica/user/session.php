
<?php
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$servername = "localhost";
$uname = "root";
$pass = "";
$dbname = "etronica";

// Create connection
$connection = new mysqli($servername, $uname, $pass, $dbname);
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

session_start();// Starting Session
// Storing Session
$user_check=$_SESSION['login_user'];
// SQL Query To Fetch Complete Information Of User
//$ses_sql=mysql_query("select username from login where username='$user_check'", $connection);

 $sql = "SELECT * FROM student_info WHERE user='$user_check'";
 $result = $connection->query($sql);
 if ($result->num_rows == 1) 
 {
	while($row = $result->fetch_assoc()) 
	{
		$login_session = $row['username'];
	}
  }	

if(!isset($login_session))
{
	$connection->close(); // Closing Connection
	header('Location: index.php'); // Redirecting To Home Page
}
?>
