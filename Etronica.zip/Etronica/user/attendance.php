<?php
session_start();
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Attendance Record</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/login.css">	

    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

    
</head>
<body>


        <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
       <?php require('header.php'); ?>
   
        
        
<div class="content mt-3">            
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN= $_GET["prn"];
$PRN = $_SESSION['login_user'];
$i = 0;
$cnt = 0;
$cnt1 = 0;
$j = 0;
$k = 0;



  // $sql = "SELECT SC.PRN PRN,DE.PRN PRN FROM satellite_communication SC JOIN digital_electronics DE ON(SC.PRN = DE.PRN)";
 $sql = "SELECT * FROM be_eln_attendance WHERE PRN = '$PRN' AND SubjectName='Satellite Communication'";
 $sql1 = "SELECT * FROM be_eln_attendance WHERE PRN = '$PRN' AND SubjectName='Digital Electronics'";
 $sql2 = "SELECT * FROM be_eln_attendance WHERE PRN = '$PRN' AND SubjectName='Embedded System Design'";   
$result = $conn->query($sql);
$result1 = $conn->query($sql1);
$result2 = $conn->query($sql2);
   if ($result->num_rows > 0) {

 echo '<div class="container">
	<div class="row">
	    <div class="col-md-11 col-xs-12 col-sm-12">
		<h4 style="text-transform:uppercase">'.$PRN.' Attendance Record  <br> <br></h4>
		<table class="table table-bordered table-striped">
		<thead class="text-primary"><tr>
		<td>Subject Name</td>
		<td>Sessions Completed</td>
		<td>Session Attended</td>
		<td>% Attendance</td>
		</thead>';
    // output data of each row
    while($row = $result->fetch_assoc()) {
	$j++;
	$sub = $row["SubjectName"];
	}	
   while($row = $result1->fetch_assoc()) {
	$i++;
	$sub1 = $row["SubjectName"];
	}
   while($row = $result2->fetch_assoc()) {
	$k++;
	$sub2 = $row["SubjectName"];
	}	
	$a = ($j * 100) / 5 ;
	$a1 = ($i * 100) / 5 ;
	$a2 = ($k * 100) / 4 ;
	echo '<tr><td>'.$sub.'</td>
	      <td>5</td>
		<td>'.$j.'</td>
		<td>'.$a.'%</td></tr>';
	echo '<tr><td>'.$sub1.'</td>
	      <td>5</td>
		<td>'.$i.'</td>
		<td>'.$a1.'%</td></tr>';
	echo '<tr><td>'.$sub2.'</td>
	      <td>4</td>
		<td>'.$k.'</td>
		<td>'.$a2.'%</td></tr>';
echo '</table></div>
</div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Data found to display
</div>';
}
$conn->close();
?>

        
        </div> <!-- .content -->
    </div><!-- /#right-panel -->


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>

    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script>
    
    </script>  
</body>
</html>
