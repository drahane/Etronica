<?php
// Start the session
session_start();
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Student Attendance</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/login.css">	

    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">  
    
</head>
<body>


        <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
       <?php require('header.php'); ?>
        
        
<div  style="background-color:orange;padding-top:15px;padding-bottom:15px;">       
  <div class="container">
   <div class="row">   
        <form action="#" method="post">
<div class="col-md-12">
              <h5>Search User by PRN</h5><br>
</div>
<div class="col-md-5">
            <div class="form-group">
              <input class="form-control" type="text" name="prn">
            </div>
</div>
<div class="col-md-3">
             <input type="submit" value="Display Info" class="btn btn-primary">
</div>
        </form>
     </div>         
</div>
</div>

<br>
        
<div class="content mt-3">            
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$_SESSION["prn"] = $_POST["prn"];
$PRN = $_SESSION["prn"];
$cnt = 0;
$cnt1 = 0;
$j = 0;
$k = 0;

 $sql = "SELECT * FROM be_eln_attendance WHERE PRN = '$PRN' AND SubjectName='Satellite Communication'";
 $sql1 = "SELECT * FROM be_eln_attendance WHERE PRN = '$PRN' AND SubjectName='Digital Electronics'";
 $sql2 = "SELECT * FROM be_eln_attendance WHERE PRN = '$PRN' AND SubjectName='Embedded System Design'";   
$result = $conn->query($sql);
$result1 = $conn->query($sql1);
$result2 = $conn->query($sql2);
   if ($result->num_rows > 0) {

 echo '<div class="container">
	<div class="row">
	    <div class="col-md-11 col-xs-12 col-sm-12">
		<h4 style="text-transform:uppercase">'.$PRN.' Attendance Record  <br> <br></h4>
		<table class="table table-bordered table-striped">
		<thead class="text-primary"><tr>
		<td>Subject Name</td>
		<td>Sessions Completed</td>
		<td>Session Attended</td>
		<td>% Attendance</td>
		</thead>';
    // output data of each row
    while($row = $result->fetch_assoc()) {
	$j++;
	$sub = $row["SubjectName"];
	}	
   while($row = $result1->fetch_assoc()) {
	$i++;
	$sub1 = $row["SubjectName"];
	}
   while($row = $result2->fetch_assoc()) {
	$k++;
	$sub2 = $row["SubjectName"];
	}	
	$a = ($j * 100) / 5 ;
	$a1 = ($i * 100) / 5 ;
	$a2 = ($k * 100) / 4 ;
	echo '<tr><td>'.$sub.'</td>
	      <td>5</td>
		<td>'.$j.'</td>
		<td>'.$a.'%</td></tr>';
	echo '<tr><td>'.$sub1.'</td>
	      <td>5</td>
		<td>'.$i.'</td>
		<td>'.$a1.'%</td></tr>';
	echo '<tr><td>'.$sub2.'</td>
	      <td>4</td>
		<td>'.$k.'</td>
		<td>'.$a2.'%</td></tr>';
echo '</table></div>
</div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Data found to display
</div>';
}
$conn->close();
?>



        </div> <!-- .content -->
    </div><!-- /#right-panel -->


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>

    

    
    </script>  
</body>
</html>
