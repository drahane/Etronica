 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN = $_GET["PRN"];
$sql = "INSERT INTO hostel_entry_record (Sr,PRN, ScanDate, ScanTime) VALUES ('', '$PRN', CURDATE(), CURTIME())";
if ($conn->query($sql) === TRUE) {
    //echo "<script> window.alert('New record create;
	
}	

$conn->close();
        ?>
