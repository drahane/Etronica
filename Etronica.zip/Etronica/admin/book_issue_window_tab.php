  
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN = $_GET['PRN'];
$ban = "SELECT BanID FROM student_info WHERE prn='$PRN'";
$result1 = $conn->query($ban);
   if ($result1->num_rows == 1) {
    while($row = $result1->fetch_assoc()) 
	{$banid = $row["BanID"];}
}
if($banid == 1)
{ echo '<div class="container">
	<div class="row">   	 
	    <div class="col-md-10 col-xs-12 col-sm-12">
	<div class="alert alert-danger"><h3>Sorry !! '.$PRN.' you are banned to use this facility. <br>Please Contact to Admin</h3></div></div></div></div>';
} 
else
{  
   $sql = "SELECT * FROM student_info WHERE prn='$PRN'";
   $result = $conn->query($sql);
   if ($result->num_rows > 0) {

  echo '<div class="container">
	<div class="row">   	 
	    <div class="col-md-8 col-xs-12 col-sm-12">
	<div class="alert alert-success">';
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
	        echo '  <h3 style="text-transform:uppercase;">  '.$row["fname"].' '.$row["lname"].' ('.$row["prn"].')</h3><br>';
	}	
	echo '<form action="#" method="post">
	<input type="text" name="booksearch">
	<input type="submit" class="btn btn-primary" value="Search Book by ID" name="submit">
	</form><br>';
	echo '<br>';
	
	if (isset($_POST['submit'])) 
	{ $book = $_POST["booksearch"];
	  $sql1 = "SELECT * FROM book_list WHERE BookID='$book'";
	  $result1 = $conn->query($sql1);
	  if ($result1->num_rows > 0)
		{
			while($row1 = $result1->fetch_assoc()) 
			{
			echo '	
				<table class="table table-striped">
				<tr>
				<td>Book ID</td>
				<td>Book Name</td>
				<td>Book Author</td>
				<td>   </td>
				</tr>
				<tr>
				<td>'.$row1["BookID"].'</td>
				<td>'.$row1["BookName"].'</td>
				<td>'.$row1["BookAuthor"].'</td>
				<td><form action="#" method="post"><input type="submit" name="bookissue" value="Issue Book" class="btn btn-success"></form></td>
				</table>';	
				$bname = $row1["BookName"];
				$bid = $row1["BookID"];
				$bauthor = $row1["BookAuthor"];
			//if data matched then insert enrty into database and set return date
				
			}
		}
	}
	if (!empty($bid)) 
	{
$sql2 = "INSERT INTO book_issue_record (Sr, PRN, BookID, BookName, BookAuthor, idate, rdate,Status) VALUES ('','$PRN','$bid','$bname','$bauthor',NOW(), NOW(),'NR')";
$sql3 = "UPDATE book_issue_record SET rdate = DATE_ADD(idate, INTERVAL 7 DAY)";}
	echo '</div></div></div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Smart Card is Swiped
</div>';
}}
$conn->close();
?>

