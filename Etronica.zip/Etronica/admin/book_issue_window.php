<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Book Issue Counter</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

   
</head>
<body>
        <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
	      <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                  <a class="navbar-brand" href="./"><h4>E-TRONICA</h4></a>

            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Menu</h3><!-- /.menu-title -->
                   
                    <li>
                        <a href="add_new_student.php"> <i class="menu-icon ti-user"></i>Add new Student </a>
                    </li>
                    
                    <li>
                        <a href="student_info.php"> <i class="menu-icon ti-info-alt"></i>Student Info </a>
                    </li>
                      <li>
                        <a href="acadmics.php"> <i class="menu-icon ti-panel"></i>Acadmics</a>
                    </li>
		      <li>
                        <a href="library.php"> <i class="menu-icon ti-panel"></i>Library</a>
                    </li>
		    <li>
                        <a href="lab_issue.php"> <i class="menu-icon ti-panel"></i>Lab Issue</a>
                    </li>
                    <li>
                        <a href="attendance.php"> <i class="menu-icon ti-panel"></i>Attendance</a>
                    </li>
		     <li>
                        <a href="hostel_mess.php"> <i class="menu-icon ti-panel"></i>Hostel & Mess</a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        	<h4>WALCHAND COLLEGE OF ENGINEERING, SANGLI</h4>
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                                <a class="nav-link" href="#"><i class="fa fa- user"></i>My Profile</a>
                                <a class="nav-link" href="#"><i class="fa fa- user"></i>Notifications <span class="count">13</span></a>
                                <a class="nav-link" href="#"><i class="fa fa -cog"></i>Settings</a>
                                <a class="nav-link" href="#"><i class="fa fa-power -off"></i>Logout</a>
                        </div>
                    </div>
                </div>
                
            </div>

        </header><!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-md-10 col-sm-4">
                <div class="page-header">
                    <div>

                    </div>
                </div>
            </div>
          
        </div>


<div class="content mt-3">
  
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN = $_GET['PRN'];
$ban = "SELECT BanID FROM student_info WHERE prn='$PRN'";
$result1 = $conn->query($ban);
   if ($result1->num_rows == 1) {
    while($row = $result1->fetch_assoc()) 
	{$banid = $row["BanID"];}
}
if($banid == 1)
{ echo '<div class="container">
	<div class="row">   	 
	    <div class="col-md-10 col-xs-12 col-sm-12">
	<div class="alert alert-danger"><h3>Sorry !! '.$PRN.' you are banned to use this facility. <br>Please Contact to Admin</h3></div></div></div></div>';
} 
else
{  
   $sql = "SELECT * FROM student_info WHERE prn='$PRN'";
   $result = $conn->query($sql);
   if ($result->num_rows > 0) {

  echo '<div class="container">
	<div class="row">   	 
	    <div class="col-md-8 col-xs-12 col-sm-12">
	<div class="alert alert-success">';
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
	        echo '  <h3 style="text-transform:uppercase;">  '.$row["fname"].' '.$row["lname"].' ('.$row["prn"].')</h3><br>';
	}	
	echo '<form action="#" method="post">
	<input type="text" name="booksearch">
	<input type="submit" class="btn btn-primary" value="Search Book by ID" name="submit">
	</form><br>';
	echo '<br>';
	
	if (isset($_POST['submit'])) 
	{ $book = $_POST["booksearch"];
	  $sql1 = "SELECT * FROM book_list WHERE BookID='$book'";
	  $result1 = $conn->query($sql1);
	  if ($result1->num_rows > 0)
		{
			while($row1 = $result1->fetch_assoc()) 
			{
			echo '	
				<table class="table table-striped">
				<tr>
				<td>Book ID</td>
				<td>Book Name</td>
				<td>Book Author</td>
				<td>   </td>
				</tr>
				<tr>
				<td>'.$row1["BookID"].'</td>
				<td>'.$row1["BookName"].'</td>
				<td>'.$row1["BookAuthor"].'</td>
				<td><form action="#" method="post"><input type="submit" name="bookissue" value="Issue Book" class="btn btn-success"></form></td>
				</table>';	
				$bname = $row1["BookName"];
				$bid = $row1["BookID"];
				$bauthor = $row1["BookAuthor"];
			//if data matched then insert enrty into database and set return date
				
			}
		}
	}
	if (!empty($bid)) 
	{
	$sql2 = "INSERT INTO book_issue_record (Sr, PRN, BookID, BookName, BookAuthor, idate, rdate,Status) VALUES ('','$PRN', '$bid', '$bname', '$bauthor',NOW(), NOW(),'NR')";
$sql3 = "UPDATE book_issue_record SET rdate = DATE_ADD(idate, INTERVAL 7 DAY)";}
	echo '</div></div></div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Smart Card is Swiped
</div>';
}}
$conn->close();
?>

    </div> <!-- .content -->
    </div><!-- /#right-panel -->
    <!-- Right Panel ends here -->

        


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script> 

</body>
</html>
