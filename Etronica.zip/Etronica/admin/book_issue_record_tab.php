<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
//$PRN= $_GET["prn"];// Change to the Session Variable when login is implemented
$PRN = $_SESSION["prn"];
$i = 1;
   $sql = "SELECT * FROM book_issue_record WHERE prn='$PRN'";
   $result = $conn->query($sql);
   if ($result->num_rows > 0) {

 echo '<div class="container">
	<div class="row">
	    <div class="col-md-11 col-xs-12 col-sm-12">
		<h4 style="text-transform:uppercase"><br><br>'.$PRN.' has issued following books<br> <br></h4>
		<table class="table table-bordered table-striped">
		<thead class="text-primary"><tr>
		<td>Sr.</td>
		<td>BOOK ID</td>
		<td>BOOK NAME</td>
		<td>BOOK AUTHOR</td>
		<td>ISSUE DATE</td>
		<td>RETURN DATE</td>
		<td>STATUS</td>
		</thead>';
    // output data of each row
    while($row = $result->fetch_assoc()) {

        echo '  
		<tr>
		<td>'.$i++.'</td>
		<td>'.$row["BookID"].'</td>
		<td>'.$row["BookName"].'</td>
		<td>'.$row["BookAuthor"].'</td>
		<td>'.$row["idate"].'</td>
		<td>'.$row["rdate"].'</td>
		<td>'.$row["Status"].'</td>
		</tr>';
	}	

	echo '</table></div>

</div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Data found to display
</div>';
}
$conn->close();
?>
