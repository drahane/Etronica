<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$messpay = $_SESSION["messpay"];
$fname = $_SESSION["fname"];
$lname = $_SESSION["lname"];
$PRN = $_SESSION["PRN"];
echo "<script> alert('The Student 2014BEN068 Successfully Subcribed for mess');</script>";
//echo "Hello".$messpay.$fname.$lname;
if(!empty($messpay))
{	
	$sql1 = "INSERT INTO mess_payment_record (Sr, PRN, PayDate, Amount) VALUES ('', '$PRN', CURDATE(), '$messpay')";
	if ($conn->query($sql1) === TRUE) 
{
   echo 'Mr'.$fname.' '.$lname.'has subscibed for mess';

	
}
}
?>
		
