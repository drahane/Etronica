<nav class="navbar navbar-expand-sm navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                  <a class="navbar-brand" href="./"><h4>E-TRONICA</h4></a>

            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
               <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Menu</h3><!-- /.menu-title -->
                   
                    <li>
                        <a href="add_new_student.php"> <i class="menu-icon ti-user"></i>Add new Student </a>
                    </li>
                    
                    <li>
                        <a href="student_info.php"> <i class="menu-icon ti-info-alt"></i>Student Info </a>
                    </li>
                   
		      <li>
                        <a href="library.php"> <i class="menu-icon ti-panel"></i>Library</a>
                    </li>
		    <li>
                        <a href="lab_issue.php"> <i class="menu-icon ti-panel"></i>Lab Issue</a>
                    </li>
                    <li>
                        <a href="attendance.php"> <i class="menu-icon ti-panel"></i>Attendance</a>
                    </li>
		     <li>
                        <a href="hostel_mess.php"> <i class="menu-icon ti-panel"></i>Hostel & Mess</a>
                    </li>
                    
                </ul>
     
            </div><!-- /.navbar-collapse -->
        </nav>


    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

       <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                       	<h4>WALCHAND COLLEGE OF ENGINEERING, SANGLI</h4>
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <?php echo'<img class="user-avatar rounded-circle" src="images/'.$_SESSION["login_admin"].'.jpg" alt="'.$_SESSION["login_admin"].'">'; ?>
                        </a>

                        <div class="user-menu dropdown-menu">
                                <a class="nav-link" href="my_profile.php"><i class="fa fa- user"></i>My Profile</a>
                                <a class="nav-link" href="logout.php"><i class="fa fa-power -off"></i>Logout</a>
                        </div>
                    </div>
                </div>
                
            </div>

        </header><!-- /header -->
        <!-- Header-->
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

