<?php
include'login1.php';
//include'session.php';
if(!isset($_SESSION['login_admin'])){
header("location: login.php");
}

?>



<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SMART STUDENT CARD</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>


        <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <?php require('header.php'); ?>
   

        <div class="content mt-3">

            <div class="row">
             <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-user text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Total Active User</div>
                                <div class="stat-digit">1024</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
             <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-layout-grid2 text-success border-success"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text"> Installed RFID</div>
                                <div class="stat-digit">120</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-money text-warning border-warning"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Total Revenue</div>
                                <div class="stat-digit">770</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
            </div>
                
            
             <div class="card col-lg-2 col-md-4 no-padding no-shadow">
                	<a href="add_new_student.php" title="add new user"> 
                <div class="card-body bg-flat-color-2">

                       <div class="h1 text-muted text-right mb-4">
                        <i class="fa fa-user-plus text-light"></i>
                       </div>
                    <small class="text-uppercase font-weight-bold text-light">Add New Student</small>
                </div>
                    </a>
            </div>
            <div class="col-md-1">
            </div>
	<a href="ban_student.php">
            <div class="card col-lg-2 col-md-4 no-padding no-shadow">
                <div class="card-body bg-flat-color-4">
                    <div class="h1 text-muted text-right mb-4">
                        <i class="fa fa-ban text-light"></i>
                    </div>
                    <small class="text-uppercase font-weight-bold text-light">Ban Student</small>
                </div>
	</a>
           

        
        </div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel ends here -->

    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script>
   

</body>
</html>
