<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$bid = $_SESSION["bid"];
$PRN = $_SESSION["PRN"];	
$sql = "UPDATE book_issue_record SET Status='R' WHERE BookID = '$bid' AND PRN = '$PRN'";
if ($conn->query($sql) === TRUE) {
echo '<script> alert("Book with id'.$bid.'is issued to '.$PRN.'")';
}
	
?>
