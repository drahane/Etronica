<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
    error_reporting(0);
	if(isset($_POST['sscyear']))
	{
		$sscyear = $_POST['sscyear'];
	}
	if(isset($_POST['hscyear']))
	{
		$hscyear = $_POST['hscyear'];
	}
	if(isset($_POST['blood']))
	{
		$bloodgrp = $_POST['blood'];
	}
	if(isset($_POST['hostel']))
	{
		$hostel = $_POST['hostel'];
	}
	if(isset($_POST['branch']))
	{
		$branch = $_POST['branch'];
	}
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
	$prn = $_POST['prn'];
        $mobile = $_POST['umob'];
        $email = $_POST['email'];
	$aadhar = $_POST["aadhar"];
        $address = $_POST['address']; 	
	$parent = $_POST['parent'];
	$bloodgrp = $_POST['blood'];
	$dob = $_POST['dob'];
	$image = $_POST["uimg"];
      	$sscyear  = $_POST['sscyear'];
	$sscschool = $_POST['sscschool'];
	$sscpercentage = $_POST['sscpercentage'];
	$hscyear  = $_POST['hscyear'];
	$hscschool = $_POST['hscschool'];
	$hscpercentage = $_POST['hscpercentage'];
	$user = $fname.$lname;
	$userpass =$fname.$lname;
if(!empty($prn) && !empty($mobile))
{ $sql = "INSERT INTO student_info (id, fname, mname, lname, branch, prn, umob, email, aadhar, address, parent, blood, dob, sscyear, sscschool, sscpercentage,hscyear, hscschool, hscpercentage,Hostel,username, userpass) VALUES ('','$fname','$mname','$lname','$branch','$prn', '$mobile', '$email', '$aadhar', '$address','$parent', '$bloodgrp','$dob','$sscyear', '$sscschool','$sscpercentage','$hscyear', '$hscschool', '$hscpercentage', '$hostel', '$user', '$userpass')";
if ($conn->query($sql) === TRUE) {
	if(!empty($prn) && !empty($mobile))
	   header('Location: successful.php?umob='.$mobile);	
} 
}

$conn->close();
?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Add New Student</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

    
</head>
<body>
        <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
       <?php require('header.php'); ?>



<div class="content mt-3">
  <div class="col-md-10 col-md-offset-2" sytle="padding-left:10%;">
    <div class="alert alert-info" style="padding-left:10%;padding-right:15%;opacity:0.6;">            
      <form action="add_new_student.php" method="post">
      	
	     <h3><span class="menu-icon ti-user"> </span>Personel Information</h3><hr>
<div class="col-md-4">
         <div class="form-group">
            <label>First Name</label>
            <input class="form-control" type="text" name="fname" placeholder="Enter First Name" required>
          </div>
</div>
<div class="col-md-4">
         <div class="form-group">
            <label>Middle Name</label>
            <input class="form-control" type="text" name="mname" placeholder="Enter Middle Name" required>
          </div>
</div>
<div class="col-md-4">
         <div class="form-group">
            <label>Last Name</label>
            <input class="form-control" type="text" name="lname" placeholder="Enter Last Name" required>
          </div>
</div>
	
	 <div class="form-group">
                <label>Branch</label>
                <select class="form-control" name="branch">
                    <option value="Electronics Engineering">Electronics Engineering</option>
                    <option value="Electrical Engineering">Electrical Engineering</option>
                    <option value="Computer Science And Engineering">Computer Science And Engineering</option>
                    <option value="Information Technology">Information Technology</option>
                    <option value="Mechanical Engineering">Mechanical Engineering</option>
                    <option value="Civil Engineering">Civil Engineering</option>
                </select>
            </div>

	<div class="form-group">
            <label>Roll Number</label>
            <input class="form-control" type="text" name="prn" placeholder="Enter PRN" required>
          </div>

          <div class="form-group">
            <label>Mobile Number</label>
            <input class="form-control" type="text" name="umob" Placeholder="Enter Mobile Number" required>
           </div>

         <div class="form-group">
            <label>Email</label>
            <input class="form-control" type="email" name="email" placeholder="Enter Email Id" required>
         </div>

            <div class="form-group">
                <label>Aadhar Number</label>
                <input class="form-control" type="text" name="aadhar" placeholder="Enter Aadhar card number" required>
            </div>

            <div class="form-group">
                <label>Address</label>
                <input class="form-control" type="text" name="address" placeholder="Enter Address" required>
            </div>
	   <div class="form-group">
                <label>Parent's / Guardian's Name </label>
                <input class="form-control" type="text" name="parent" placeholder="Enter Parent's / Guardian's Name" required>
            </div>
	  <div class="form-group">
                <label>Blood Group</label>
                <select class="form-control" name="blood">
                    <option value="A">A</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                </select>
            </div>
	    <div class="form-group">
                <label>Date of Birth </label>
                <input class="form-control" type="text" name="dob" placeholder="Enter Date of Birth" required>
            </div>
	 <div class="form-group">
                <label>Staying in Hostel</label>
                <select class="form-control" name="hostel">
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
		</select>
	</div>

            <div class="form-group">
                <label>User Photo</label><br>
                <input  type="file" name="uimg" placeholder="Upload Passport size image">
            </div>
            <br><br>
	       <h3><span class="menu-icon ti"></span> Education Profile</h3><hr>

            <div class="form-group">
                <label>SSC Passing Year</label>
                <select class="form-control" name="sscyear">
                    <option value="2010">2010</option>
                    <option value="2011">2011</option>
                    <option value="2012">2012</option>
                    <option value="2013">2013</option>
                    <option value="2014">2014</option>
                    <option value="2015">2015</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                </select>
            </div>

            <div class="form-group">
                <label>SSC School Name</label>
                <input class="form-control" type="text" name="sscschool" placeholder="Enter SSC School name" required>
            </div>

            <div class="form-group">
                <label>SSC %</label>
                <input class="form-control" type="text" name="sscpercentage" placeholder="Enter %ssc" required>
            </div>
		<div class="form-group">
                <label>HSC/Diploma Passing Year</label>
                <select class="form-control" name="hscyear">
                    <option value="2010">2010</option>
                    <option value="2011">2011</option>
                    <option value="2012">2012</option>
                    <option value="2013">2013</option>
                    <option value="2014">2014</option>
                    <option value="2015">2015</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                </select>
            </div>

            <div class="form-group">
                <label>HSC/Diploma College Name</label>
                <input class="form-control" type="text" name="hscschool" placeholder="Enter HSC/Diploma School name" required>
            </div>

            <div class="form-group">
                <label>HSC/Diploma %</label>
                <input class="form-control" type="text" name="hscpercentage" placeholder="Enter %hsc/Diploma" required>
            </div>
            <br>
		  	
            <br>
            <div  style="padding-left:35%;" >
                <input class="btn btn-primary btn-lg" type="submit" value="Register User">
            </div><br><br><br>
            </form>
        </div>
    </div>
    </div> <!-- .content -->
    </div><!-- /#right-panel -->
    <!-- Right Panel ends here -->

        


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script> 

</body>
</html>
