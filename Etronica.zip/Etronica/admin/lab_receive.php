<?php
session_start();
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Book Receive Window</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/login.css">	

    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

 
    
    
</head>
<body>


        <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
       <?php 
	require('header.php');
	?>
        
        
<div class="content mt-3">            
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN= $_GET["prn"];
$i = 1;
 $_SESSION["PRN"] = $PRN;
   $sql = "SELECT * FROM lab_issue_record WHERE prn='$PRN' ORDER BY rdate DESC";
   $result = $conn->query($sql);
   if ($result->num_rows > 0) {

 echo '<div class="container">
	<div class="row">
	    <div class="col-md-11 col-xs-12 col-sm-12">
		<h4 style="text-transform:uppercase">'.$PRN.' has issued following books<br> <br></h4>
		<table class="table table-bordered table-striped">
		<thead class="text-primary"><tr>
		<td>Sr.</td>
		<td>BOOK ID</td>
		<td>BOOK NAME</td>
		<td>BOOK AUTHOR</td>
		<td>ISSUE DATE</td>
		<td>RETURN DATE</td>
		<td>STATUS</td>
		</thead>';
    // output data of each row
    while($row = $result->fetch_assoc()) {
	if($row["Status"] == 'NR')
	{  
		$status = "<form action='book_issue_confirmation.php' method='post'> <input type='submit' value='Receive' name='submit' class='btn btn-primary'></form>";
	}
	else
	{
		$status = "RETURNED";
	}

        echo '  
		<tr>
		<td>'.$i++.'</td>
		<td>'.$row["BookID"].'</td>
		<td>'.$row["BookName"].'</td>
		<td>'.$row["BookAuthor"].'</td>
		<td>'.$row["idate"].'</td>
		<td>'.$row["rdate"].'</td>
		<td>'.$status.'</td>
		</tr>';
	if($i >1 && $status == "RETURNED")
	{break;}
	else
	{
	$_SESSION["bid"] = $row["BookID"];
	}
	}	


	echo '</table></div>
</div></div>';

} else {
    echo '<div class="alert alert-danger">
 No Data found to display
</div>';
}
$conn->close();
?>

        
        </div> <!-- .content -->
    </div><!-- /#right-panel -->


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script>  


</body>
</html>
