<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 	error_reporting(0);
        $cid = $_POST['CompID'];
        $cname = $_POST['CompName'];
if(!empty($cid) && !empty($cname))
{ $sql = "INSERT INTO component_list (Sr, CompID, CompName) VALUES ('', '$cid', '$cname')";
if ($conn->query($sql) === TRUE) {
	//if(!empty($name) && !empty($mobile))
	   //header('Location: successful.php?umob='.$mobile);	
} 
}

$conn->close();
?>
<div class="content mt-3">
  <div class="col-md-8 col-md-offset-3" sytle="padding-left:10%;">
    <div class="alert alert-info" style="padding-left:10%;padding-right:15%;opacity:0.6;">            
      <form action="#" method="post">
      	
	     <h3><span class="menu-icon ti-user"> </span>Component Information</h3><hr>
         <div class="form-group">
            <label>Component ID</label>
            <input class="form-control" type="text" name="CompID" placeholder="Enter Component Id" required>
          </div>

          <div class="form-group">
            <label>Component NAME</label>
            <input class="form-control" type="text" name="CompName" Placeholder="Enter Component Name" required>
           </div>

            	
            <br>
            <div  style="padding-left:35%;" >
                <input class="btn btn-primary btn-lg" type="submit" value="Insert Component">
            </div><br><br><br>
            </form>
        </div>
    </div>
    </div> <!-- .content -->
