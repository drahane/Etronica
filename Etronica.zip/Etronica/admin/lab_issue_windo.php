<?php
session_start();
?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Lab Issue Counter</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

 
</head>
<body>
        <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
       <?php require('header.php'); ?>
   

<div class="content mt-3">
  
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
$PRN = $_GET['PRN'];
$ban = "SELECT BanID FROM student_info WHERE prn='$PRN'";
$result1 = $conn->query($ban);
   if ($result1->num_rows == 1) {
    while($row = $result1->fetch_assoc()) 
	{$banid = $row["BanID"];}
}
if($banid == 1)
{ echo '<div class="container">
	<div class="row">   	 
	    <div class="col-md-10 col-xs-12 col-sm-12">
	<div class="alert alert-danger"><h3>Sorry !! '.$PRN.' you are banned to use this facility. <br>Please Contact to Admin</h3></div></div></div></div>';
} 
else
{  
  
   $sql = "SELECT * FROM student_info WHERE prn='$PRN'";
   $result = $conn->query($sql);
   if ($result->num_rows > 0) {

  echo '<div class="container">
	<div class="row">   	 
	    <div class="col-md-8 col-xs-12 col-sm-12">
	<div class="alert alert-success">';
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
	        echo '  <h3 style="text-transform:uppercase;">  '.$row["fname"].' '.$row["lname"].' ('.$row["prn"].')</h3><br>';
	}	
	echo '<form action="#" method="post">
	<input type="text" name="compsearch">
	<input type="submit" class="btn btn-primary" value="Search Component by ID" name="submit">
	</form><br>';
	echo '<br>';
	
	if (isset($_POST['submit'])) 
	{ $comp = $_POST["compsearch"];
	  $sql1 = "SELECT * FROM component_list WHERE CompID='$comp'";
	  $result1 = $conn->query($sql1);
	  if ($result1->num_rows > 0)
		{
			while($row1 = $result1->fetch_assoc()) 
			{
			echo '	
				<table class="table table-striped">
				<tr>
				<td>Component ID</td>
				<td>Component Name</td>
				<td>   </td>
				</tr>
				<tr>
				<td>'.$row1["CompID"].'</td>
				<td>'.$row1["CompName"].'</td>
				<td><form action="#" method="post"><input type="submit" name="compissue" value="Issue Component" class="btn btn-success"></form></td>
				</table>';	
				$cname = $row1["CompName"];
				$cid = $row1["CompID"];
				
			//if data matched then insert enrty into database and set return date
				
			}
		}
	}
	if (!empty($cid)) 
	{
	$sql2 = "INSERT INTO lab_issue_record (Sr, PRN, CompID, CompName, idate) VALUES ('','$PRN', '$cid', '$cname', NOW())";
	if ($conn->query($sql2) === TRUE){}
	}
	
	echo '</div></div></div></div>';	
} else {
    echo '<div class="alert alert-danger">
 No Smart Card is Swiped
</div>';
}
}
$conn->close();
?>

    </div> <!-- .content -->
    </div><!-- /#right-panel -->
    <!-- Right Panel ends here -->

        


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script> 

</body>
</html>
