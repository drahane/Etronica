<?php 
session_start();
//include('login1.php'); // Includes Login Script
error_reporting(0);
if(isset($_SESSION['login_user'])){
header("location: index.php");
}

?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login to Etronica</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="assets/css/login.css">
   
<style>
     body{
            margin: 0;
            padding: 0;
            background: url(../user/images/login2.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            font-family: sans-serif;
        }
</style>
   
</head>
<body>
<div class="loginbox">
    <img src="images/man-avatar.png" class="user">
    <h3 style="color:yellow;">E-Tronica Admin Login</h3>
    
    <form action="login1.php" method="POST">
        <p>USERNAME</p>
        <input type="text" name="username">
        <p>Password</p>
        <input type="password" name="password">
        <input type="submit" name="submit" value="Log In">
        <a href="#">Forget Password</a>
	<span><?php echo $error; ?>        
    </form>
</div>

    </body>
</html> 
