<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "etronica";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed:" . $conn->connect_error);
	}
 	error_reporting(0);
	if(isset($_POST['ban']))
	{
		$ban_reason = $_POST['ban'];
	}

	$prn = $_POST['prn'];
        $bantext = '<div class="alert alert-danger" style="padding-left:10%;padding-right:15%;opacity:0.6;">  
		Successfully Banned The Student</div>';
	if(!empty($prn))
	{ 
		$sql = "UPDATE student_info SET BanID = '1', Remark = '$ban_reason' WHERE prn = '$prn'";
		if ($conn->query($sql) === TRUE) 
		{
			echo ' <script>document.getElementById("other").innerHTML = " '.$bantext.'"</script>';
		} 
	}
	if(isset($_POST['unban']))
	{
		$unbanprn = $_POST["unbanprn"];
		if(!empty($unbanprn))
		{ 
			$sql1 = "UPDATE student_info SET BanID = '0' WHERE prn = '$unbanprn'";	
			if ($conn->query($sql1) === TRUE) {}
		}
	}
$conn->close();
?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ban Student</title>
    <meta name="description" content="Vehicle Tracking System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

</head>
<body>
       <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
       <?php require('header.php'); ?>

<div class="content mt-3">
  <div class="col-md-7 col-md-offset-3" sytle="padding-left:10%;">
    <div class="alert alert-danger" style="padding-left:10%;padding-right:15%;opacity:0.6;">            
      <form action="#" method="post" name="myForm">
	     <h3><span class="menu-icon ti-user"> </span>Ban Student from Facilities</h3><hr>
 	     <div class="form-group">
        	    <label>PRN Number</label>
        	    <input class="form-control" type="text" name="prn" placeholder="Enter PRN Number " required>
             </div>
	     <div class="form-group">
                <label>Reason for Banning the Student</label>
                <select class="form-control" name="ban">
                    <option value="Not Submitted the Books" default>Not Submitted the Books</option>
                    <option value="Not Submitted Lab Equipment">Not Submitted Lab Equipment</option>
                    <option value="Has Damaged the Property of Institute">Has Damaged the Property of Institute </option>
                    <option value="Student has leaved the Institute">Student has leaved the Institute</option>
                    <option value="other">Other</option>

                </select>
            </div>

	   <div class="form-group" id = "other">
	   </div>
	   <br>
           <div  style="padding-left:35%;" >
                <input class="btn btn-danger btn-lg" type="submit" value="Ban Student">
           </div><br><br><br>
        </form>
      </div>
    </div>
<!-- Un banning Starts Here-->
	<div class="col-md-5 col-md-offset-3" sytle="padding-left:10%;">
	    <div class="alert alert-success" style="padding-left:10%;padding-right:15%;opacity:0.6;">    	
		<form action = "#" method="post" >
		 <h3> <br> <span class="menu-icon ti-user"> </span>UnBan Student from Facilities</h3><hr>
	         <div class="form-group">
        	    <label>PRN Number</label>
        	    <input class="form-control" type="text" name="unbanprn" placeholder="Enter PRN Number " required>
        	 </div><br>
		<div  style="padding-left:20%;" >
                	<input class="btn btn-success btn-lg" type="submit" name="unban" value="UnBan Student">
 	        </div><br><br><br><br>
	      </form>
	   </div>
	</div>

   </div> <!-- .content -->
  </div><!-- /#right-panel -->
 <!-- Right Panel ends here -->
  


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script> 

</body>
</html>
