<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 	error_reporting(0);
        $bid = $_POST['BookID'];
        $bname = $_POST['BookName'];
        $bauthor = $_POST['BookAuthor'];
if(!empty($bid) && !empty($bname))
{ $sql = "INSERT INTO book_list (Sr, BookID, BookName, BookAuthor) VALUES ('', '$bid', '$bname', '$bauthor')";
if ($conn->query($sql) === TRUE) {
	//if(!empty($name) && !empty($mobile))
	   //header('Location: successful.php?umob='.$mobile);	
} 
}

$conn->close();
?>
<div class="content mt-3">
  <div class="col-md-8 col-md-offset-3" sytle="padding-left:10%;">
    <div class="alert alert-info" style="padding-left:10%;padding-right:15%;opacity:0.6;">            
      <form action="#" method="post">
      	
	     <h3><span class="menu-icon ti-user"> </span>Book Information</h3><hr>
         <div class="form-group">
            <label>BOOK ID</label>
            <input class="form-control" type="text" name="BookID" placeholder="Enter Book Id" required>
          </div>

          <div class="form-group">
            <label>BOOK NAME</label>
            <input class="form-control" type="text" name="BookName" Placeholder="Enter Book Name" required>
           </div>

         <div class="form-group">
            <label>BOOK AUTHOR</label>
            <input class="form-control" type="text" name="BookAuthor" placeholder="Enter Author" required>
         </div>

            	
            <br>
            <div  style="padding-left:35%;" >
                <input class="btn btn-primary btn-lg" type="submit" value="Insert Book">
            </div><br><br><br>
            </form>
        </div>
    </div>
    </div> <!-- .content -->
