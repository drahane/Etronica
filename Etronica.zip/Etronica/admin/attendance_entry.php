 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "etronica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
error_reporting(0);
//Initiating Varible from post 
$PRN = $_POST["prn"];
$uid = $_POST["uid"];
//$PRN = $_GET["prn"];
//$uid = $_GET["uid"];
//Selecting Subject According to Card Swiped
switch($uid)
{
	case 1:
		$SubName = "Satellite Communication";
		break;
	case 2:
		$SubName = "Digital Electronics";
		break;
	case 3:
		$SubName = "Embedded System Design";
		break;
	default:
		break;
}
//Inserting Data into table
$sql = "INSERT INTO be_eln_attendance (Sr, PRN, SubjectName, ScanDate, Scantime) VALUES ('', '$PRN', '$SubName', CURDATE(), CURTIME() )";
if ($conn->query($sql) === TRUE) {
    //echo "<script> window.alert('New record create;
	
}

$conn->close();
        ?>
